// Modal window control

var modalButton = document.getElementsByClassName('modal_button');
var alertButton = document.getElementsByClassName('alert_button');


var modalWindow = document.getElementsByClassName('modal_wrapper')[0];
var alertWindow = document.getElementsByClassName('alert_wrapper')[0];


function toggleModal() {
    modalWindow.classList.toggle('hidden_wrapper')
}
//second modal view
function toggleAlert() {
    alertWindow.classList.toggle('hiddenAlert_wrapper')
}

for (var i = 0; i < modalButton.length; i++){
    modalButton[i].onclick =toggleModal;
}

for (var i = 0; i < alertButton.length; i++){
    alertButton[i].onclick =toggleAlert;
}

var reg_btn = document.getElementById('reg_btn');
function validate() {
    var temp = false;


    var arr = [];
    var inputs = document.getElementsByClassName('form-control');

    for (var i = 0; i < inputs.length; i++){

        if(inputs[i].value <= 0){
            inputs[i].classList.add('wrong_data');
            temp = false;
        } else {
            inputs[i].classList.remove('wrong_data');
            temp = true;
            //add all value in one array
            arr= [inputs[0].value,inputs[1].value,inputs[2].value,inputs[3].value]
        }

    }

    if (temp == true){
        action();
    }else{
        //Validation of the fields
        if (inputs[0].value){
            pattern = /[а-яА-Яa-zA-Z]/;
            text = inputs[0].value;
            if (pattern.test(text)){
                if (inputs[1].value){
                    pattern = /\b[a-z0-9._]+@[a-z0-9.-]+\.[a-z]{2,4}\b/i;
                    text = inputs[1].value;
                    if (pattern.test(text)){
                        if (inputs[2].value){
                            pattern = /[а-яА-Яa-zA-Z0-9]/;
                            text = inputs[2].value;
                            if (pattern.test(text)){
                                if (inputs[3].value){
                                    pattern = /\b[0-9._]\b/i;
                                    text = inputs[3].value;
                                    if (pattern.test(text)){
                                    }else{
                                        alert("Your Name " +text + "is not valid!");
                                    }
                                }
                            }else{
                                alert("Your Email " +text  + "is not correct");
                            }
                        }
                    }else{
                        alert("Your Password " +text + "has to be 1-8 symbols");
                    }
                }
            }else{
                alert ("Your Phone " +text + "is not valid!");
            }
        }
    }
}

//using Esc for close modal
window.onkeydown = function( event ) {
    if ( event.keyCode == 27 ) {
        closeModal();
        closeAlert()
    }
};
// close register firm show alert
function action() {
    closeModal();
    toggleAlert();
}

function closeModal() {
    modalWindow.classList.add('hidden_wrapper')
}
function closeAlert() {
    alertWindow.classList.add('hiddenAlert_wrapper')
}

reg_btn.onclick = validate

